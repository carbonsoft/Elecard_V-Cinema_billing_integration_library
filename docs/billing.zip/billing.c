//////////////////////////////////////////////////////////////////////////
//
//	created:	Dec 23 2009
//	file name:	billing.h
//
//////////////////////////////////////////////////////////////////////////
//
//	Copyright (c) 2008 Elecard.
//	All rights are reserved.  Reproduction in whole or in part is prohibited
//	without the written consent of the copyright owner.
//
//	Elecard reserves the right to make changes without
//	notice at any time. Elecard makes no warranty, expressed,
//	implied or statutory, including but not limited to any implied
//	warranty of merchantability of fitness for any particular purpose,
//	or that the use will not infringe any third party patent, copyright
//	or trademark.
//
//	Elecard must not be liable for any loss or damage arising
//	from its use.
//
//////////////////////////////////////////////////////////////////////////
//
//  Author: Boris Vanin <Boris.Vanin@elecard.ru>
//	purpose:
//
//////////////////////////////////////////////////////////////////////////

// uncomment to use GLib
#include <glib.h>

#include <stdlib.h>
#include <string.h>

#include <billing.h>

typedef struct {
	int		allow_to_all;
} billing_config;

/**
 * 
 * @param instance 
 * @param action 
 * @return  if ( billing_verify_action ) { action is allowed } else { action is denyed }
!0 action is allowed
 0 action is denyed
	
  Warning  Return value is ignored for events:
		BILLING_EVENT_CONNECT
		BILLING_EVENT_DISCONNECT
*/
int				billing_verify_action		(void* instance, billing_action* action){
	billing_config*	conf = (billing_config*)instance;
	
	int			allowed = 0; // not allowed by default
	
	if( conf->allow_to_all ){
		allowed = 1;
	}
	// How to change RTSP client_port
	if ( action->proto == BILLING_PROTO_RTSP ){
		if ( action->event == BILLING_EVENT_SETUP ){
			if ( strcmp("vod", action->xworks_module) == 0 ){
				//action->client_port1 = 2222;
			}
		}
	}
	return allowed;
}



/**
 * 
 * @param config_file_path 
 * @param glib_main_loop 
 * @return 
 */
void*			billing_open_instance		(const char* config_file_path, void* glib_main_loop){
	
	billing_config*		conf = malloc(sizeof(billing_config));
	
	if ( conf ){
		// read your own config file from given directory: config_file_path
		conf->allow_to_all	= 1;
	}
	return conf;
}

/**
 * 
 * @param instance 
 */
void			billing_close_instance		(void* instance){
	billing_config*		conf = (billing_config*)instance;
	
	free(conf);
	
}
